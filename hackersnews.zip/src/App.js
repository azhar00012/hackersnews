import React from 'react';
import './App.css';
// import Nav from './Nav';
import HackerNews from './HackerNews';

function App() {
  return (
    <div className="container-fluid">
      {/* <Nav /> */}
      <HackerNews />
    </div>
  );
}

export default App;
